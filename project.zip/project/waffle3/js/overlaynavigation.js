   /* Open when user clicks on the span element */
   function openNav() {
    document.getElementById('myNav').style.display = 'block';
    document.getElementById("myNav").style.width = "100%";
}

/* Close when user clicks on the "x" symbol inside the overlay */
function closeNav() {
    document.getElementById('myNav').style.display = 'none';
    document.getElementById("myNav").style.width = "0%";
}